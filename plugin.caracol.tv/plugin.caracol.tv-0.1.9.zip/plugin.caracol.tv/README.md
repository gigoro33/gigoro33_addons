# plugin.caracol.tv

Complemento no oficial para acceder al contenido de la página Caracol TV a través de Kodi.

Ni este complemento ni su autor están afiliados de ninguna manera a Caracol Televisión